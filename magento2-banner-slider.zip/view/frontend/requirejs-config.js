var config = {
    map: {
        '*': {
        },
    },
    paths: {
        'acx/slider': 'Acx_Slider/js/flexslider-min'
    },
    shim: {
        'acx/slider': {
            deps: ['jquery']
        },
    }
};
